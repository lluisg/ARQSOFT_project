Session 6 has been implemented
