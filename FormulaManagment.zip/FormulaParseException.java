public class FormulaParseException extends RuntimeException {
  public FormulaParseException(String msg) {
    super(msg);
  }
}