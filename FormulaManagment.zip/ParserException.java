public class ParserException extends RuntimeException {
  public ParserException(String msg) {
    super(msg);
  }
}